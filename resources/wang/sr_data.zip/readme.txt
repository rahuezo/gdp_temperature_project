File name convention
--------------------
- "sr" denotes root zone storage capacity.
- "cru" denotes estimate using CRU precipitation data, and the mean of
  SSEBop and MODIS 16 evaporation data over the period 2003-2013. 
- "chirps" denotes estimate using CHIRPS precipitation data, and the mean 
  of CMRSET, SSEBop, and MODIS 16 evaporation data over the period 2003-2012.
- "max" denotes sr estimated from maximum storage deficit over 
  the available data time series.  
- "Xyrs" denotes Gumbel-normalised sr with X years of drought return period.

unit: millimeter 


Citation and documentation
--------------------------
Wang-Erlandsson, L., Bastiaanssen, W.G.M., Gao, H., Jägermeyr, J., 
Senay, G., van Dijk, A., Guerschmann, J.P., Keys, P., Gordon, L. J. 
and Savenije, H. H. G.: Global root zone storage capacity from 
satellite-based evaporation, Hydrol. Earth Syst. Sci. Disc., XXX.
(!!! Will be updated!)


Contact
--------
Lan Wang-Erlandsson

lan.wang@su.se
l.wang-2@tudelft.nl